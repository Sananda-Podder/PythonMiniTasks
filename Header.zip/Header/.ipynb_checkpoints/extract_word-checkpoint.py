# importing the module
# import chardet
import re
import csv

# open the file in read mode
filename = open("Output_Final.xlsx", 'r', encoding='utf-8')
# with open('Output_Final.xlsx', 'r') as f:
#     enc = chardet.detect(f.read())  # or readline if the file is large
# creating dictreader object
file = csv.DictReader(filename)

header = []
subHeader = []

# for col in file:
#     print(col)
