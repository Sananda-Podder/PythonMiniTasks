# importing the module
import chardet
import re
import csv
import openpyxl
import pandas as pd
import numpy as np
import string

from string import punctuation

# open the file in read mode
filename = open("C:\\Users\\SANANDA\\Downloads\\Header\\Header\\Output_Final.csv", 'r', errors="ignore")
# with open('Output_Final.xlsx', 'rb') as f:
#     enc = chardet.detect(f.read())  # or readline if the file is large
# print(enc)
# creating dictreader object
file = csv.DictReader(filename)
print(file)
header = []
subHeader = []
first_word_h = list()
last_word_h = list()

first_word_sh = list()
last_word_sh = list()
for col in file:
    header.append(col["Heading"])
    subHeader.append(col["Subheading"])
print(list(set(header)))
print(list(set(subHeader)))
unique_header = list(set(header))
unique_subheading = list(set(subHeader))
for h in unique_header:
    # print(h.split(" "))
    first_word_h.append(h.split(" ")[0])
    last_word_h.append(h.split(" ")[-1])

print("********** Heading *************")
print(first_word_h)
print(last_word_h)

for sh in unique_subheading:
    # print(sh.split(" "))
    first_word_sh.append(sh.split(" ")[0])
    last_word_sh.append(sh.split(" ")[-1])

# Printing header and subheader first and last word
# print(first_word_h)
# print(last_word_h)
#

print("********** Sub Heading ************")
print(first_word_sh)
print(last_word_sh)

# def word_position_header(pattern):
#     # match = None
#     for string in header:
#         match = re.search(pattern, string)
#         if match:
#             print(f"Match {match} found at {match.start()} and {match.end()}")
#             print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
#
#         else:
#             print("Not found")
#
#
# def word_position_sub_header(pattern):
#     for string in subHeader:
#         match = re.search(pattern, string)
#         if match:
#             print(f"Match {match} found at {match.start()} and {match.end()}")
#             print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
#
#         else:
#             print("Not found")


# print("******************* Heading First word ********************")

# for a in first_word_h:
#     word_position_header(a)
#
# print("***************** Heading Last word *************************")
#
# for b in last_word_h:
#     word_position_header(b)
#
# print("******************* Sub Heading First word ********************")
#
# for f in first_word_sh:
#     word_position_sub_header(f)
#
# print("***************** Sub Heading Last word *************************")
#
# for l in last_word_sh:
#     word_position_sub_header(l)

start_pos = []
end_loc = []


def locate_word(word, sentence):
    # To omit the punctuations
    sentence = sentence.translate(str.maketrans('', '', string.punctuation))

    if word in sentence.split():
        res = sentence.split().index(word) + 1
        start_pos.append(res)


    else:
        res = -1
    end_pos = res + len(word) - 1
    if res != -1:
        end_loc.append(end_pos)
    # print("The location of word is : " + str(res))
    print(f"The {word} is at {res} and end at {end_pos} ")


punctuations = []

for a in last_word_h:
    for h in unique_header:
        locate_word(a, h)
# for a in last_word_sh:
#     for h in unique_subheading:
#         locate_word(a, h)
for header in unique_header:
    print(header)
    # punctuations = [w for w in header if w in punctuation]
    for w in header:
        if w in string.punctuation:
            punctuations.append(w)
#
#     for f in last_word_sh:
#         locate_word(f, header)
for header in unique_header:
    for i in header:
        if i in string.punctuation:
            print(re.findall(r"\w+|[^\w\s]", header).index(i) + 1)

print(punctuations)
print(start_pos)
print(end_loc)

# Storing result to New Excel


some_dict = dict(Heading=unique_header, HeaderFirstWord=first_word_h, HeaderLastWord=last_word_h,
                 HeaderWordStartPosition=start_pos, HeaderWordEndPosition=end_loc)
#
print(some_dict)

df = pd.DataFrame(dict([(key, pd.Series(value)) for key, value in some_dict.items()]))

df.replace(np.nan, 0, inplace=True)
print(df)

df.to_excel("Output_1.xlsx", index=False)


# some_dict = dict(Heading=unique_subheading, SubHeadingFirstWord=first_word_sh, HeaderLastWord=last_word_sh,
#                  SubHeaderFirstWordPosition=start_pos, SubHeaderLastWordPosition=end_loc)
# #
# print(some_dict)
#
# df = pd.DataFrame(dict([(key, pd.Series(value)) for key, value in some_dict.items()]))
#
# df.replace(np.nan, 0, inplace=True)
# print(df)
#
# df.to_excel("Output_2.xlsx", index=False)

print(len(unique_header))
print(len(first_word_h))
print(len(last_word_h))
print(len(start_pos))
print(len(end_loc))
