

from tabula import read_pdf

file = "C:\\Users\\SANANDA\\Downloads\\test 1.pdf"


df_temp = read_pdf(file, stream=True)